package com;

public class Exam {
	
	Paper p;
	
	Exam(Paper p){
		this.p = p;
	}
	
	 Paper getPaper(){
		return p ;
	}
	
	
}
