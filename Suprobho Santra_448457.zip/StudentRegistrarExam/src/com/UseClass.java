package com;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;


public class UseClass {

	static Student s1 = new Student("Abhijit", "Single", 'M', LocalDate.of(1994, 05, 06), "Kolkata", "abc@gmail.com", "None", "100", "B-Tech", "Indian");
	static Student s2 = new Student("Pagla", "Married", 'M', LocalDate.of(1991, 02, 03), "Durgapur", "xyz@gmail.com", "None", "200", "B-Tech", "Indian");
	static Student s3 = new Student("Hati", "Married", 'F', LocalDate.of(1990, 04, 05), "Medinapore", "pqr@gmail.com", "None", "300", "M-Tech", "Indian");
	static Student s4 = new Student("Mouse", "Married", 'M', LocalDate.of(1985, 06, 07), "Shibpur", "stq@gmail.com", "None", "400", "B-Tech", "Indian");
	static Student s5 = new Student("Tanmoy", "Married", 'F', LocalDate.of(1972, 07, 07), "Salt Lake", "hij@gmail.com", "None", "500", "B-Tech", "Indian");

	public static void main(String[] args) {		

		ArrayList<Student> stdArray = new ArrayList<Student>();
		stdArray.add(s1);
		stdArray.add(s2);
		stdArray.add(s3);
		stdArray.add(s4);
		stdArray.add(s5);

		System.out.println("Original Data");
		System.out.println("*******************************************************************************************************************************************************************************************");
		Student.display(stdArray);

		System.out.println();
		System.out.println("Sort by Student Age");
		System.out.println("*******************************************************************************************************************************************************************************************");
		Collections.sort(stdArray);
		Student.display(stdArray);


		Registrar reg = Registrar.getRegistrar();
		for(int i = 0 ; i<stdArray.size(); i++) {
			Student std=stdArray.get(i);
			int j=i+1;
			std.setSeatCount(j);
			std.admitStudent();
//			reg.studentDetails(std);
			if(std.getAdmissionId()!=0) {
				std.registerForExam();
				std.appearForExam();
			}
		}

	}
}
