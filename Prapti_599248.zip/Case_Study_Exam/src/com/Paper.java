package com;

public class Paper {
	
	public String submit(){
		Evaluator ev = new Evaluator();
		return ev.evaluate(this);
	}
	
}