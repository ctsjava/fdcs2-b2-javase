package com;

public class AgeException extends Exception {
	
	private static final long serialVersionUID = 20L;
	public AgeException(String msg) {
		
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
