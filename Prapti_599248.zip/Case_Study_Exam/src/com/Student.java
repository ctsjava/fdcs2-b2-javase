package com;

import java.io.Serializable;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;
import java.util.List;

public class Student implements Serializable, Comparable<Student> {

	private String name;
	private String maritalStatus;
	private int age;
	private char sex;
	private LocalDate dob;
	private String address;
	private String primaryEmailId;
	private String secondaryEmailId;
	private String phoneNumber;
	private String highestEducation;
	private String nationality;

	private int admissionId;
	private String result;
	private Exam exam;
	public static final int max_seat = 30;
	private int seatCount;

	@Override
	public int compareTo(Student std) {
		return age - std.getAge();
	}

//	Student(){}

	Student(String Name, String Marital_Status, char Sex, LocalDate DateofBirth, String Address, String PrimaryEmailid,
			String SecondaryEmailid, String PhoneNumber, String HighestEducationQualification, String Nationality) {
		this.name = Name;
		this.maritalStatus = Marital_Status;
// 		this.age = Age;
		this.sex = Sex;
		this.dob = DateofBirth;
		this.address = Address;
		this.primaryEmailId = PrimaryEmailid;
		this.secondaryEmailId = SecondaryEmailid;
		this.phoneNumber = PhoneNumber;
		this.highestEducation = HighestEducationQualification;
		this.nationality = Nationality;
		// -- Calculate Age

	}

	void admitStudent() {
		admissionId = Registrar.getRegistrar().registerStudent(this);
		if (admissionId == -1) {
			System.exit(admissionId);
		}
		this.setAdmissionId(admissionId);
		System.out.println("Your admit ID is : " + admissionId);
	}

	void registerForExam() {
		this.exam = ExamRegistrar.getExamRegistrar().registeringStudentForExamination(this);
	}

	void appearForExam() {
		Paper p = exam.getPaper();
		result = p.submit();
		System.out.println("----------------------");
		System.out.println("Your result is   : " + result);
		System.out.println("----------------------");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public int getAge() {
		Period period = Period.between(getDob(), LocalDate.now());
		this.age = period.getYears();
		return age;
	}

//	public void setAge(int age) {
//		Period period = Period.between(getDob(), LocalDate.now());
//		this.age = period.getYears(); 
//		this.age = age;
//	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public String getSecondaryEmailId() {
		return secondaryEmailId;
	}

	public void setSecondaryEmailId(String secondaryEmailId) {
		this.secondaryEmailId = secondaryEmailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getHighestEducation() {
		return highestEducation;
	}

	public void setHighestEducation(String highestEducation) {
		this.highestEducation = highestEducation;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public int getAdmissionId() {
		return admissionId;
	}

	public void setAdmissionId(int admissionId) {
		this.admissionId = admissionId;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public int getSeatCount() {
		return seatCount;
	}

	public void setSeatCount(int seatCount) {
		this.seatCount = seatCount;
	}

	public static void display(List<Student> stds) {
		System.out.println(
				"Student Name\tMarital Status\tAge\t\tSex\t\t\tDOB\t\t\tAddress\t\tPrimary Email ID\tSecondary Email ID\tPhone Number\tHighest Qualification\tNationality");
		System.out.println(
				"=================================================================================================");
		for (Student std : stds) {
			System.out.print(std.getName() + "\t\t");
			System.out.print(std.getMaritalStatus() + "\t\t");
			System.out.print(std.getAge() + "\t\t");
			System.out.print(std.getSex() + "\t" + "\t\t");
			System.out.print(std.getDob() + "\t\t");
			System.out.print(std.getAddress() + "\t\t");
			System.out.print(std.getPrimaryEmailId() + "\t\t");
			System.out.print(std.getSecondaryEmailId() + "\t");
			System.out.print(std.getPhoneNumber() + "\t");
			System.out.print(std.getHighestEducation() + "\t");
			System.out.print(std.getNationality() + "\t");

//			Period diff= Period.between(emp.getDob(),LocalDate.now());
//			System.out.print(diff.getYears()+"\t");
			System.out.println();
		}
		System.out.println(
				"=================================================================================================");
	}

}
