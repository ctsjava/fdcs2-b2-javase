package com;

public class Validator {

	
	private Validator(){}
	
	
	public static Validator getValidator(){
		Validator val = new Validator();
		return val; 
	}
	
	public String validateStudentDetails(Student std) 
		throws AgeException{
		System.out.println("std.getAge(): "+std.getAge());
		if ((std.getAge() >= 23) && (std.getAge() <= 35)) {
           return "thanks";
		} else {
			throw new AgeException("Age out of bounds");
		}
	}
	
}
