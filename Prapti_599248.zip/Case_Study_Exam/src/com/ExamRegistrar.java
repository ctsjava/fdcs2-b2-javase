package com;

public class ExamRegistrar {
	
	private ExamRegistrar() {}

	static ExamRegistrar getExamRegistrar() {
		ExamRegistrar exr = new ExamRegistrar();
		return exr;
	}
	
	public Exam registeringStudentForExamination(Student std){
		Paper p = new Paper();
		Exam ex = new Exam(p);
		return ex;
		
	}
	
}
	
	
