package com;

public class Evaluator {
	
	Evaluator(){}
	
	public static ExamRegistrar getEvaluator(){
		return ExamRegistrar.getExamRegistrar();
	}
	
	public String evaluate(Paper p) {
		String result = "Pass";
		return  result;
	}
}
