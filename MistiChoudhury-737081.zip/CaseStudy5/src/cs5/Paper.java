package cs5;

public class Paper {

}
