package cs5;

import java.util.ArrayList;
import java.util.Iterator;

public class Registrar {
	
	static int admissionId=0;
	public static boolean validateStudent(Student st) 
	{
		Validator vl=new Validator();
		System.out.println();
		System.out.println("***** Calling Student Validation Process *****");
		System.out.println();
		boolean validate=vl.validateStudent(st);
		return validate;
	}
	
	public void registerStudent(ArrayList al,Student st)
	{
		
		int size=al.size();
		int maxCapacity=5; //Enrollment capacity set to 5 in place of 30
		
		//System.out.println("Checking seat Capacity");
		try {
			if (size+1<=maxCapacity)
			{
				if(validateStudent(st))
				{
					System.out.println("Student "+st.getName()+" successfully validated");
					al.add(st);
					System.out.println("Student "+st.getName()+" successfully registered");
					System.out.println("Seats Remaining: "+(maxCapacity-(size+1)));					
					
				}
			}
			else
			{
				throw new sizeException("Student "+st.getName()+" not registered as maximum seat capacity reached !!");
			}
			System.out.println();
		} catch (sizeException e) {
			// TODO: handle exception
			System.out.println(e);
			System.out.println();
		}			
		
	}
	
	public  void evaluationProcess(ArrayList al)
	{
		Iterator it=al.iterator();
		while(it.hasNext())
		{
			Student st=(Student)it.next();
			System.out.println();
			System.out.println("Getting examiner for evaluation of  "+st.getName());
			Examiner ex=new Examiner();
			ex.createExam();
			st.setResult(ex.getResult());
			System.out.println("Getting exam result: "+st.getResult());
			admissionId=admissionId+1;
			System.out.println("New Admission Id created: "+admissionId);					
			st.setAdmissionId(admissionId);
			System.out.println();
			System.out.println("*******************");
		}
	}
	
	public void displayStudent(ArrayList al)
	{
		Iterator it=al.iterator();
		while(it.hasNext())
		{
			Student st=(Student)it.next();
			
			System.out.println( st.getName()+"\t"+st.getMaritalStatus() +"\t"+st.getAge() +"\t"+st.getSex() +"\t"+st.getDateOfBirth() +"\t"+st.getAddress() +"\t"+ st.getPrimaryEmailId()+"\t"+st.getSecondaryEmaiId() +"\t"+st.getPhoneNumber() +"\t"+st.getInterestedSubject() +"\t"+st.getHighestEducationQualification() +"\t"+st.getNationality()+"\t"+st.getResult() +"\t"+st.getAdmissionId());
		}
	}
	
	public SortByName sortName()
	{
		return(new SortByName()); 
	}

}
