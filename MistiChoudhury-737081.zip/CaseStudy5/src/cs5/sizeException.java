package cs5;

public class sizeException extends Exception{
	
	String msg;
	sizeException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ("Exception !!!"+msg);
	}
}
